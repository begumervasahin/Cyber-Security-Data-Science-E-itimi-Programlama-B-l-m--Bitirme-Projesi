import axios from "axios"
import { useEffect, useState } from "react";
import { format } from "date-fns";
import './App.css';
const baseUrl = "http://localhost:5000"; //backend den gelmekte


function App() {
  const [description, setDescription] = useState("");
  const [editDescription, setEditDescription] = useState("");
  const [eventsList, setEventsList] = useState([]);
  const [eventId, setEventId] = useState(null);

 // Etkinlikleri getirme işlemi burada aapıldı
  const fetchEvents = async () => {
    const data = await axios.get(`${baseUrl}/events`);

    const { events } = data.data
    setEventsList(events);

  }
  // değerin değişikliği burda yapıldı
  const handleChange = (e, field) => {

    if (field == 'edit') {
      setEditDescription(e.target.value);
    }
    else {
      setDescription(e.target.value);
    }
  }

 // Düzenleme modunu aç/kapat
  const toggleEdit = (event) => {
    setEventId(event.id);
    setEditDescription(event.description);
  }

// Etkinlik silme
  const handleDelete = async (id) => {
    try {
      await axios.delete(`${baseUrl}/events/${id}`);

      const updatedList = eventsList.filter(event => event.id !== id);
      setEventsList(updatedList);

    } catch (error) {
      console.error(error.message);
    }

  }

  // Form gönderme
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editDescription) {
        const data = await axios.put(`${baseUrl}/events/${eventId}`, {description: editDescription});
        const updatedEvent= data.data.event;
        const updatedList = eventsList.map(event => {
          if (event.id == eventId)
          {
            return event=updatedEvent
          }
          return event
        })
        setEventsList(updatedList)
        
      } 
      else{
        const data = await axios.post(`${baseUrl}/events`, {description})
        setEventsList([...eventsList,data.data]);
      
      }
      setDescription('');
      setEditDescription('');
      setEventId(null);
    } catch (error) {
      console.error(error.message);

    }

  }

  useEffect(() => {
    fetchEvents();
  }, [])
  return (
    <div className="App">
      <div className="overlay">

      <section>
        <form onSubmit={handleSubmit}>
          <label htmlFor="description">TODO LİST</label>
          <input
            onChange={(e) => handleChange(e, 'description')}
            type="text"
            name="description"
            id="description"
            placeholder=" "
            value={description} />
          <button  className="ekle" type="submit">EKLE</button>
        </form>

      </section>
      <section>
        <ul>
          {eventsList.map(event => {

            if (eventId == event.id) {
              return (
                <form onSubmit={handleSubmit} key={event.id}>
                  <input
                    onChange={(e) => handleChange(e, 'edit')}
                    type="text"
                    name="editDescription"
                    id="editDescription"
                    value={editDescription}
                  ></input>
                  <button type="submit">GÜNCELLE</button>

                </form>
              )

            } else {

              return (

                <li style={{ display: "flex" }} key={event.id}>
                  {event.description}
                  <button onClick={() => toggleEdit(event)}>DÜZENLE</button>
                  <button onClick={() => handleDelete(event.id)}>SİL</button>
                </li>
              )

            }
          })}
        </ul>

      </section>
      <p style={{ color: "white" }}>© 2023 Begüm Erva Şahin. All rights reserved.</p>


    </div>
    </div>
  );
}

export default App;
